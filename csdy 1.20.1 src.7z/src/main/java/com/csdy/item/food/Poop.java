package com.csdy.item.food;

import com.csdy.until.List.GodList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class Poop extends ItemGenericFood {

    public Poop() {
        super(15, 15F, false, false, true, 1);
    }

    @Override
    public void onFoodEaten(ItemStack stack, Level worldIn, LivingEntity livingEntity) {
        livingEntity.addEffect(new MobEffectInstance(MobEffects.SATURATION, 300, 0));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level worldIn, LivingEntity livingEntity) {
        super.finishUsingItem(stack, worldIn, livingEntity);
        Player player = (Player) livingEntity;
        CompoundTag tag = player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        String firstshit = "first_shit";
        if (!tag.getBoolean(firstshit)){
        player.displayClientMessage(Component.literal("你居然连这个都吃!但是不会给你成就的"), false);
        player.getPersistentData().getBoolean("first_death");
        tag.putBoolean(firstshit, true);
        player.getPersistentData().put(Player.PERSISTED_NBT_TAG, tag);
        }
        return livingEntity instanceof Player && ((Player) livingEntity).getAbilities().instabuild ? stack : new ItemStack(Items.BOWL);
    }
}

