package com.csdy.item.sword.sword;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

public class Lapis extends SwordItem {
    public Lapis(Tier pTier, int pAttackDamageModifier, float pAttackSpeedModifier, Properties pProperties) {
        super(pTier, pAttackDamageModifier, pAttackSpeedModifier, pProperties);
    }
}
