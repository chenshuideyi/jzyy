package com.csdy.until.timestop;

public class rubishi {
//    ServerPlayer spplayer = (ServerPlayer)entity;
//            PlayerList list = spplayer.server.getPlayerList();
//            list.remove(spplayer);
//            list.deop(spplayer.getGameProfile());
//            entity.gameEvent(GameEvent.ENTITY_DIE);
//            entity.fallDistance = 2.14748365E9F;
//            ((ServerPlayer) entity).heal(-65535);
}
