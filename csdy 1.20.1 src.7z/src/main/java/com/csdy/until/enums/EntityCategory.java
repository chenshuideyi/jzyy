package com.csdy.until.enums;

public enum EntityCategory {
    normal,csdy,csdykill
}
