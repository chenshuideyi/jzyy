package com.csdy.until;

import com.csdy.until.enums.EntityCategory;
import com.csdyms.Helper;
import net.minecraft.world.entity.Entity;

public class EntityUntil {
    public static EntityCategory getCategory(Entity entity) {
        try {
            return Helper.getFieldValue(Entity.class.getDeclaredField("csdy$entityCategory"), entity, EntityCategory.class);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }
    public static void setCategory(Entity entity, EntityCategory info) {
        try {
            Helper.setFieldValue(Entity.class.getDeclaredField("csdy$entityCategory"), entity, info);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }
    public static void setCsdyKill(Entity entity) {
        setCategory(entity, EntityCategory.csdykill);
    }


}
